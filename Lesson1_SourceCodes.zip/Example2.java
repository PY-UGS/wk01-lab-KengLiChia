public class Example2 {
    public static void main(String[] args) {
        String moduleCode ="CSC1009";
        switch (moduleCode) {
            case "CSC1009":
                System.out.println("Object-Oriented Programming");
                break;

            default:
                System.out.println("After switch");
                break;
        }
    }
}
