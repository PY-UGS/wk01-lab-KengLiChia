public class Example3 {
    public static void main(String[] args) {
        System.out.println("Value of i: ");
        for (int i = 102; i > 66; i--) {
            if (i%2 !=0){
                System.out.print(i + ",");
            }
        }
    }
}
